from setuptools import setup, find_packages

setup(
    name='table_generator',
    version='0.4',
    packages=find_packages(),
    install_requires=[]
)
